Here's how to make this panel working:

1. Log into facebook
2. Go to this link http://www.facebook.com/notifications.php
3. Click Via RSS
4. Copy the address for the RSS link and copy it into this panel's settings. Apply.