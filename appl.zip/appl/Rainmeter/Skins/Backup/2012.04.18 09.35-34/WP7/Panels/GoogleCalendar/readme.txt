Here's how to get this panel working:

1. Go to this link: https://www.google.com/calendar/render
2. Log in if you haven't already
3. Go to your calendar settings
4. Click the Calendar tab
5. Click on your calendar (username@gmail.com)
6. Scroll down, and under Private Address click XML
7. Copy the XML address into the panel