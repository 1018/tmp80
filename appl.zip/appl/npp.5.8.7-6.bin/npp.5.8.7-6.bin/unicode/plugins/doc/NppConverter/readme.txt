NppConvert is a ASCII<->Hex converter plugin for Notepad++.

It converts selected text (hexadecimal string or ASCII string) to ASCII or hexadecimal string according your choice.
The format of generated hex string can be set by modifying the parameters in the section [ascii2Hex] of converter.ini (it's necessary to restart Notepad++). 
For the "Hex -> ASCII" command's input hex string format, NppConverter is smart enough to detect it.
This plugin provide also a conversion panel. It could be useful when you need convert a value into ASCII, decimal, hexadecimal, octadecimal and binary.

This plugin is under GPL.

Don Ho <don.h@free.fr>
