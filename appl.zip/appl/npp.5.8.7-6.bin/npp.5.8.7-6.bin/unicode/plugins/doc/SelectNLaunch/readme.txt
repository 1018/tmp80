Select 'N' Launch is a plugin of Notepad++.

Its basic feature is get your selected text, save it as file with the extension you customized in the system temporary directory, then call system to open it with the extension associated program.
In my personal usage, I defined crt and pdf as extension, then I can launch pdf or show a certificate on the fly, by selecting a Base64 text and executing the defined commands.

Upto 20 commands (20 extensions) are customizable in this plugin.

Enjoy

Don Ho
don.h@free.fr